from flask import Flask, render_template, url_for

app = Flask(__name__)


@app.route('/')
def ok():
    return render_template('base.html', title='Готовимся к миссии', h1='Миссия Колонизация Марса', h4='И на Марсе будут яблони цвести!')

@app.route('/training/<prof>')
def ok_2(prof):
    return render_template('base.html', title='Готовимся к миссии', h1='Миссия Колонизация Марса', h4='И на Марсе будут яблони цвести!', prof=prof)

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
